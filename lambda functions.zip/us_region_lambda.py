import pymysql
import json
from datetime import datetime
import traceback

# Database configuration
DB_HOST = "a9ce700e2283447668b04449a19ba784-889059d6801beaad.elb.ap-southeast-1.amazonaws.com"
DB_PORT = 80
DB_USER = "root"
DB_PASSWORD = "xM2809@coolcat"
DB_NAME_US = "us_region_v1"
DB_NAME_CENTRALIZED = "centralized_v1"


def lambda_handler(event, context):
    try:
        print("Event Received:", event)
        body = json.loads(event["body"]) if "body" in event else event

        # Extract fields
        vehicle_id = body.get('vehicle_id')
        motion = body.get('motion')
        location = body.get('location')
        country_code = body.get('country_code')
        export = body.get('export')
        timestamp = body.get('timestamp')

        if not all([vehicle_id, location, country_code, export is not None, timestamp]):
            raise ValueError(
                "Missing required data: 'vehicle_id', 'location', 'country_code', 'export', or 'timestamp'")

        # Process values
        location_json = json.dumps(
            {"longitude": location["longitude"], "latitude": location["latitude"]})
        export_enum = 'true' if export else 'false'
        motion_enum = 'true' if motion else 'false'
        sent_time = datetime.fromisoformat(timestamp)
        latency = (datetime.utcnow() - sent_time).total_seconds()

        connection = pymysql.connect(
            host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASSWORD)
        cursor = connection.cursor()

        if export:
            print(
                f"Export flag is true for vehicle_id {vehicle_id}. Updating centralized_db.")
            cursor.execute(f"USE {DB_NAME_CENTRALIZED}")

            cursor.execute(
                "SELECT update_count, cumulative_latency FROM vehicles_data WHERE vehicle_id = %s AND country_code = %s", (vehicle_id, country_code))
            result = cursor.fetchone()

            if result:
                update_count, cumulative_latency = result or (0, 0)
                cumulative_latency = cumulative_latency or 0
                cumulative_latency += latency
                avg_latency = cumulative_latency / (update_count + 1)
                duty_cycle = ((update_count + 1) / 60) * 100

                cursor.execute("""
                    UPDATE vehicles_data
                    SET motion = %s, update_count = update_count + 1, cumulative_latency = %s, avg_latency = %s, duty_cycle = %s
                    WHERE vehicle_id = %s AND country_code = %s
                """, (motion_enum, cumulative_latency, avg_latency, duty_cycle, vehicle_id, country_code))

            else:
                avg_latency = latency
                cursor.execute("""
                    INSERT INTO vehicles_data (vehicle_id, motion, country_code, update_count, duty_cycle, cumulative_latency, avg_latency)
                    VALUES (%s, %s, %s, 1, %s, %s, %s)
                """, (vehicle_id, motion_enum, country_code, 1.67, latency, avg_latency))

        else:
            print(
                f"Export flag is false for vehicle_id {vehicle_id}. Updating us_region_v2.")
            cursor.execute(
                f"SELECT update_count, cumulative_latency FROM {DB_NAME_SG}.vehicles_data WHERE vehicle_id = %s AND country_code = %s", (vehicle_id, country_code))
            result = cursor.fetchone()

            if result:
                update_count, cumulative_latency = result or (0, 0)
                cumulative_latency = cumulative_latency or 0
                cumulative_latency += latency
                avg_latency = cumulative_latency / (update_count + 1)
                duty_cycle = ((update_count + 1) / 60) * 100

                cursor.execute(f"""
                    UPDATE {DB_NAME_SG}.vehicles_data
                    SET motion = %s, location = %s, export = %s, update_count = update_count + 1, cumulative_latency = %s, avg_latency = %s, duty_cycle = %s
                    WHERE vehicle_id = %s AND country_code = %s
                """, (motion_enum, location_json, export_enum, cumulative_latency, avg_latency, duty_cycle, vehicle_id, country_code))

            else:
                avg_latency = latency
                cursor.execute(f"""
                    INSERT INTO {DB_NAME_SG}.vehicles_data (vehicle_id, motion, country_code, location, update_count, duty_cycle, cumulative_latency, avg_latency)
                    VALUES (%s, %s, %s, %s, 1, %s, %s, %s)
                """, (vehicle_id, motion_enum, country_code, location_json, 1.67, latency, avg_latency))

        connection.commit()
        cursor.close()
        connection.close()
        return {'statusCode': 200, 'body': json.dumps('Operation completed successfully!')}

    except Exception as e:
        print(f"Error: {traceback.format_exc()}")
        return {'statusCode': 500, 'body': json.dumps(f"Error processing data: {str(e)}")}
