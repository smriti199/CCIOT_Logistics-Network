import SwiftUI
import MapKit

struct LocationView: View {
    
    @StateObject private var locationManager = LocationManager()
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 0.0, longitude: 0.0),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )

    var body: some View {
        VStack(spacing: 20) {
            Text("Location")
                .font(.largeTitle)
                .fontWeight(.bold)

            // Display location data
            VStack(alignment: .leading, spacing: 10) {
                Text("Current Location")
                    .font(.headline)
                    .foregroundColor(.blue)
                HStack {
                    Text("Latitude")
                        .fontWeight(.semibold)
                    Spacer()
                    Text("\(locationManager.latitude, specifier: "%.9f")")
                        .foregroundColor(.gray)
                }
                HStack {
                    Text("Longitude")
                        .fontWeight(.semibold)
                    Spacer()
                    Text("\(locationManager.longitude, specifier: "%.9f")")
                        .foregroundColor(.gray)
                }
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .strokeBorder(Color.blue, lineWidth: 1)
            )

            // Display Map
            Map(coordinateRegion: $region)
                .frame(height: 300) // Adjust the height of the map as needed
                .cornerRadius(10)
                .shadow(color: .gray.opacity(0.5), radius: 5, x: 0, y: 2)
        }
        .onAppear {
            locationManager.startLocationUpdates()
            updateRegion()
        }
        .onDisappear {
            locationManager.stopLocationUpdates()
        }
        .onChange(of: locationManager.latitude) { _ in
            updateRegion()
        }
        .onChange(of: locationManager.longitude) { _ in
            updateRegion()
        }
        .padding()
    }

    // Update the map's region whenever location changes
    private func updateRegion() {
        region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: locationManager.latitude, longitude: locationManager.longitude),
            span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
        )
    }
}
