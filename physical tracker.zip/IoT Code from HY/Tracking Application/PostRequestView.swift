import SwiftUI

struct PostRequestView: View {
    @StateObject private var locationManager = LocationManager()
    @State private var responseHistory: [(timestamp: String, request: String, message: String)] = []
    @State private var isSendingRequest = false
    @State private var deviceId = "123456"
    @State private var selectedExport = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
            // Title
            Text("Manual Simulator")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.blue)
                .padding(.top, 30)

            // Location Data Display
            VStack(alignment: .leading, spacing: 10) {
                Text("Location Data")
                    .font(.headline)
                    .foregroundColor(.blue)

                HStack {
                    Text("Latitude:")
                        .fontWeight(.semibold)
                    Spacer()
                    Text("\(locationManager.latitude, specifier: "%.9f")")
                        .foregroundColor(.gray)
                }

                HStack {
                    Text("Longitude:")
                        .fontWeight(.semibold)
                    Spacer()
                    Text("\(locationManager.longitude, specifier: "%.9f")")
                        .foregroundColor(.gray)
                }
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(15)
            .foregroundColor(.black)

            // Input Fields for Device ID and Export
            VStack(alignment: .leading, spacing: 15) {
                Text("Settings")
                    .font(.headline)
                    .foregroundColor(.blue)

                HStack {
                    Text("Vehicle ID:")
                        .fontWeight(.semibold)
                    Spacer()
                    TextField("Enter Device ID", text: $deviceId)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .frame(maxWidth: 200)
                }

                Toggle("Export:", isOn: $selectedExport)
            }
            .padding()
            .background(Color(.systemGray6))
            .cornerRadius(15)
            .foregroundColor(.black)

            // Send Button
            Button(action: sendPostRequest) {
                Text("Send Location Data")
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(isSendingRequest ? Color.gray : Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .disabled(isSendingRequest)
            .opacity(isSendingRequest ? 0.6 : 1.0)

            // Response History List
                VStack(alignment: .leading, spacing: 10) {
                    Text("Response History")
                        .font(.headline)
                        .foregroundColor(.blue)
                    
                    ScrollView {
                        VStack(spacing: 10) {
                            ForEach(responseHistory.sorted { $0.timestamp > $1.timestamp }, id: \.timestamp) { entry in
                                VStack(alignment: .leading, spacing: 5) {
                                    Text("Request Sent:")
                                        .fontWeight(.semibold)
                                        .foregroundColor(.primary)
                                    Text(entry.request)
                                        .font(.caption)
                                        .foregroundColor(.blue)
                                        .padding(.bottom, 5)
                                    Text("Response: \(entry.message)")
                                        .font(.caption)
                                        .foregroundColor(.green)
                                    Text("Timestamp: \(entry.timestamp)")
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                        .frame(maxWidth: .infinity)
                                }
                                .padding()
                                .background(Color(.systemGray6))
                            }
                        }
                        .cornerRadius(15)
                    }
                }
            }
            .padding(.horizontal)
        }
        .onAppear {
            locationManager.startLocationUpdates()
        }
        .onDisappear {
            locationManager.stopLocationUpdates()
        }
    }

    // Function to send the HTTP POST request
    private func sendPostRequest() {
        guard let url = URL(string: "https://clxr1calh1.execute-api.ap-southeast-1.amazonaws.com/default/Concurrent") else {
            print("Invalid URL")
            return
        }

        let requestBody: [String: Any] = [
            "vehicle_id": deviceId,
            "motion": 1,
            "country_code": "SG",
            "location": [
                "latitude": locationManager.latitude,
                "longitude": locationManager.longitude
            ],
            "export": selectedExport,
            "timestamp": getCurrentTimestamp()
        ]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: requestBody, options: [.prettyPrinted]) else {
            print("Error converting body to JSON")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            let timestamp = getCurrentTimestamp()
            if let error = error {
                print("Request failed with error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    responseHistory.append((timestamp, String(data: jsonData, encoding: .utf8) ?? "Invalid Request", "Request failed: \(error.localizedDescription)"))
                }
                return
            }

            if let data = data, let responseString = String(data: data, encoding: .utf8) {
                DispatchQueue.main.async {
                    responseHistory.append((timestamp, String(data: jsonData, encoding: .utf8) ?? "Invalid Request", responseString))
                }
            } else {
                DispatchQueue.main.async {
                    responseHistory.append((timestamp, String(data: jsonData, encoding: .utf8) ?? "Invalid Request", "No data in response"))
                }
            }
        }

        task.resume()
    }

    // Helper function to get the current timestamp in ISO 8601 format
    private func getCurrentTimestamp() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss" // ISO 8601 format without timezone
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0) // Force UTC timezone
        return dateFormatter.string(from: Date())
    }
    
    private func getCurrentTimestampEpoch() -> String {
        return String(Int(Date().timeIntervalSince1970))
    }
}

struct PostRequestView_Previews: PreviewProvider {
    static var previews: some View {
        PostRequestView()
    }
}
