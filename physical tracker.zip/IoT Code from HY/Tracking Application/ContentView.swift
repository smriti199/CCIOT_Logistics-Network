import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            // Motion Tab
            MotionView()
                .tabItem {
                    Label("Tracking Simulator", systemImage: "waveform.path.ecg")
                }
            PostRequestView()  // Added PostRequestView as a new tab
                .tabItem {
                    Label("Manual Simulator", systemImage: "paperplane.fill")
                }
            LocationView()
                .tabItem {
                    Label("Location", systemImage: "map")
                }
        }
    }
}

