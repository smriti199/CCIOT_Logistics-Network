import SwiftUI

struct MotionView: View {
    @StateObject private var motionManager = MotionManager()
    @StateObject private var locationManager = LocationManager()
    @State private var statusMessage = "Standby"
    @State private var calculatedMagnitude: Double = 0.0
    @State private var previousMagnitude: Double = 0.0
    @State private var deltaMagnitude: Double = 0.0
    @State private var responseHistory: [(timestamp: String, request: String, response: String)] = []
    @State private var shouldSendRequest = false
    @State private var isCooldown = false
    @State private var deviceId = "123456"
    @State private var selectedExport = false
    private let vigorousThreshold: Double = 1.5
    private let deltaThreshold: Double = 1.0
    private let cooldownInterval: TimeInterval = 15.0

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Title
                Text("Tracking Simulator")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.blue)
                    .padding(.top, 30)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Accelerometer Readings")
                        .font(.headline)
                        .foregroundColor(.blue)
                        .padding(.bottom, 5)

                    VStack(spacing: 5) {
                        sensorRow(label: "X", value: motionManager.x)
                        sensorRow(label: "Y", value: motionManager.y)
                        sensorRow(label: "Z", value: motionManager.z)
                        sensorRow(label: "Magnitude", value: calculatedMagnitude)
                        sensorRow(label: "Delta", value: deltaMagnitude)
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(15)
                .foregroundColor(.black) // Apply to all child text

                // Status Message
                Text(statusMessage)
                    .font(.headline)
                    .foregroundColor(.white) // Use white text for better contrast
                    .padding()
                    .frame(maxWidth: .infinity) // Stretch the text to full width
                    .background(
                        isCooldown ? Color.orange : (calculatedMagnitude > vigorousThreshold ? Color.red : Color.green) // Solid background color
                    )
                    .cornerRadius(15) // Add rounded corners for better styling

                // ID and Export Selection
                VStack(alignment: .leading, spacing: 10) {
                    Text("Settings")
                        .font(.headline)
                        .foregroundColor(.blue)

                    HStack {
                        Text("Vehicle ID:")
                        TextField("Enter ID", text: $deviceId)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                    
                    Toggle("Export:", isOn: $selectedExport)
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(15)

                // Response History Section
                VStack(alignment: .leading, spacing: 10) {
                    Text("Response History")
                        .font(.headline)
                        .foregroundColor(.blue)

                    ForEach(responseHistory.sorted { $0.timestamp > $1.timestamp }, id: \.timestamp) { entry in
                        VStack(alignment: .leading, spacing: 5) { // Added spacing for better alignment
                            Text("Request Sent:")
                                .fontWeight(.semibold)
                                .foregroundColor(.primary) // Ensure consistency
                            Text(entry.request)
                                .font(.caption)
                                .foregroundColor(.blue)
                                .padding(.bottom, 5)
                            Text("Response:")
                                .fontWeight(.semibold)
                                .foregroundColor(.primary) // Ensure consistency
                            Text(entry.response)
                                .font(.caption)
                                .foregroundColor(.green)
                            Text("Timestamp: \(entry.timestamp)")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .frame(maxWidth: .infinity)
                        }
                        .padding() // Padding inside the card
                        .background(Color(.systemGray6)) // Background color for the card
                        .cornerRadius(15) // Rounded corners
                        .frame(maxWidth: .infinity) // Ensure the card takes up the full width
                        .padding(.vertical, 5) // Spacing between cards
                    }
                    Spacer()
                }
                .frame(maxWidth: .infinity) // Outer VStack takes full width
                .background(Color.white) // Ensure consistent background color
            }.padding(.horizontal)
        }
        .onAppear {
            locationManager.startLocationUpdates()
            motionManager.startAccelerometerDataCollection()
            motionManager.onAccelerometerUpdate = { x, y, z in
                let magnitude = sqrt(x * x + y * y + z * z)
                calculatedMagnitude = magnitude
                deltaMagnitude = abs(magnitude - previousMagnitude)
                if magnitude > vigorousThreshold && deltaMagnitude > deltaThreshold && !isCooldown {
                    statusMessage = "Sending GPS..."
                    shouldSendRequest = true
                } else if !isCooldown {
                    statusMessage = "Standby"
                    shouldSendRequest = false
                }
                previousMagnitude = magnitude
            }
        }
        .onDisappear {
            locationManager.stopLocationUpdates()
            motionManager.stopAccelerometerDataCollection()
        }
        .onChange(of: shouldSendRequest) { newValue in
            if newValue, !isCooldown {
                sendPostRequest()
                startCooldown()
            }
        }
    }

    // Sensor Row for Display
    private func sensorRow(label: String, value: Double) -> some View {
        HStack {
            Text(label)
                .fontWeight(.semibold)
            Spacer()
            Text("\(value, specifier: "%.6f")")
        }
    }

    // Function to send the HTTP POST request
    private func sendPostRequest() {
        guard let url = URL(string: "https://clxr1calh1.execute-api.ap-southeast-1.amazonaws.com/default/Concurrent") else {
            print("Invalid URL")
            return
        }

        let requestBody: [String: Any] = [
            "vehicle_id": deviceId,
            "motion": 1,
            "country_code": "SG",
            "location": [
                "latitude": locationManager.latitude,
                "longitude": locationManager.longitude
            ],
            "export": selectedExport,
            "timestamp": getCurrentTimestamp()
        ]

        guard let jsonData = try? JSONSerialization.data(withJSONObject: requestBody, options: [.prettyPrinted]) else {
            print("Error converting body to JSON")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = jsonData
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            let timestamp = getCurrentTimestamp()
            if let error = error {
                print("Request failed with error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    responseHistory.append((timestamp, String(data: jsonData, encoding: .utf8) ?? "Invalid Request", "Request failed: \(error.localizedDescription)"))
                }
                return
            }

            if let data = data, let responseString = String(data: data, encoding: .utf8) {
                DispatchQueue.main.async {
                    responseHistory.append((timestamp, String(data: jsonData, encoding: .utf8) ?? "Invalid Request", responseString))
                }
            } else {
                DispatchQueue.main.async {
                    responseHistory.append((timestamp, String(data: jsonData, encoding: .utf8) ?? "Invalid Request", "No data in response"))
                }
            }
        }

        task.resume()
    }

    // Start cooldown period
    private func startCooldown() {
        isCooldown = true
        statusMessage = "Power Saving"
        DispatchQueue.main.asyncAfter(deadline: .now() + cooldownInterval) {
            isCooldown = false
        }
    }

    private func getCurrentTimestamp() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss" // ISO 8601 format without timezone
        dateFormatter.timeZone = TimeZone(secondsFromGMT: 0) // Force UTC timezone
        return dateFormatter.string(from: Date())
    }
    private func getCurrentTimestampEpoch() -> String {
        return String(Int(Date().timeIntervalSince1970))
    }
}

#Preview {
    MotionView()
}

