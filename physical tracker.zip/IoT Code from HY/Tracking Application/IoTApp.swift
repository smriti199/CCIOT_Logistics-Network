//
//  IoTApp.swift
//  IoT
//
//  Created by Taylor Tan on 18/11/24.
//

import SwiftUI

@main
struct IoTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.light)
        }
    }
}
