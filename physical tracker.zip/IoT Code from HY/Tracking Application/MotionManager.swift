import CoreMotion
import Combine

class MotionManager: ObservableObject {
    @Published var x: Double = 0.0
    @Published var y: Double = 0.0
    @Published var z: Double = 0.0
    @Published var isDataCollecting = false
    
    var onAccelerometerUpdate: ((Double, Double, Double) -> Void)?

    private var motionManager = CMMotionManager()
    
    func startAccelerometerDataCollection() {
        if motionManager.isAccelerometerAvailable {
            motionManager.accelerometerUpdateInterval = 0.3
            motionManager.startAccelerometerUpdates(to: .main) { data, error in
                if let accelerometerData = data {
                    self.x = accelerometerData.acceleration.x
                    self.y = accelerometerData.acceleration.y
                    self.z = accelerometerData.acceleration.z
                    
                    // Call the update closure with the new values
                    self.onAccelerometerUpdate?(self.x, self.y, self.z)
                }
            }
            isDataCollecting = true
        }
    }
    
    func stopAccelerometerDataCollection() {
        motionManager.stopAccelerometerUpdates()
        isDataCollecting = false
    }
}

