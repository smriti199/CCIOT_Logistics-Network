import Foundation
import CoreLocation
import SwiftUI

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private let locationManager = CLLocationManager()

    // Use Double for more precision
    @Published var latitude: Double = 0.0
    @Published var longitude: Double = 0.0

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
    }

    // Start updating location
    func startLocationUpdates() {
        DispatchQueue.global().async {
          if CLLocationManager.locationServicesEnabled() {
              self.locationManager.startUpdatingLocation()
          }
        }
    }

    // Stop updating location
    func stopLocationUpdates() {
        locationManager.stopUpdatingLocation()
    }

    // Delegate method called when location is updated
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let newLocation = locations.last else { return }
        latitude = newLocation.coordinate.latitude
        longitude = newLocation.coordinate.longitude
    }

    // Delegate method called if there's an error in getting location
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        latitude = 0.0
        longitude = 0.0
    }
}

